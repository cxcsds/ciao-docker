# This is the Caldb initilization file for UNIX systems.  It sets up the
# 'CALDB' and 'CALDBCONFIG' environment variables.  The CALDB environment 
# variable should point at the top level directory of the Caldb and the 
# CALDBCONFIG environment variable should point at the file containing 
# paths to the index files.
# 
# This file is site dependent.  The directory paths may need to be
# edited when installing a Caldb.
#
#-----------------------------------------------------------------------

CALDB=/data/chandra_caldb/ciao; export CALDB
CALDBCONFIG=$CALDB/software/tools/caldb.config; export CALDBCONFIG
CALDBALIAS=$CALDB/software/tools/alias_config.fits; export CALDBALIAS
